# Learning Log — [ProjectName]

> **Purpose:** this file is re-read by Cursor at the start of every session (via `.cursor/rules/learning-log.mdc`). It tells Cursor the architectural decisions, patterns, and anti-patterns that apply to THIS codebase — so it stops defaulting to the internet average of .NET code.
>
> **How to update:** run the prompt in `prompts/hydrate-learning-log.md` against the codebase. Cursor will propose new entries. Accept what's correct; delete what isn't. Commit the result.
>
> **Format:** each ADR is a one-liner statement of fact. The goal is a Cursor context window ~500 words — dense, factual, no fluff.

---

## Architectural decisions (ADRs)

### ADR-001 — Result\<T\> over throw for business failures
Business-rule failures (not-found, validation, conflict) are returned as `Result<T>` using [CSharpFunctionalExtensions / project's own Result type]. We do not throw `BusinessException` or `NotFoundException` in the Application or Domain layers. Infrastructure exceptions (network, I/O) may propagate normally.

### ADR-002 — DI lifetime discipline
No Scoped service is injected into a Singleton. Any Singleton that needs transient/scoped work uses `IServiceScopeFactory`. Repositories are `AddScoped<>`. DbContext is `AddDbContext<>` (Scoped by default — never override to Singleton or Transient).

### ADR-003 — AsNoTracking on read-only queries
Every read-only EF Core query uses `.AsNoTracking()` or `.AsNoTrackingWithIdentityResolution()`. Read-model repositories apply it at the base `IQueryable` level. Only queries that flow into `SaveChangesAsync` in the same scope omit it.

---

## Patterns in use in this codebase

_Fill in as you adopt them:_

- [ ] Clean Architecture (Application → Domain ← Infrastructure)
- [ ] MediatR (CQRS with commands + queries as IRequest<T>)
- [ ] Minimal API endpoints (mapped in `Program.cs`, no controllers)
- [ ] xUnit + FluentAssertions (test project: `tests/`)
- [ ] EF Core 8+ with owned entities for value objects
- [ ] MCP server at `mcp/` (FastMCP, exposes domain tools to Cursor)

---

## Anti-patterns to avoid

_These are patterns Cursor will otherwise generate by default — the rules enforce them, but this log reinforces._

- ❌ `throw new ValidationException(...)` in Application layer → use `Result<T>`
- ❌ `services.AddSingleton<T>()` where `T` depends on `DbContext` → use `IServiceScopeFactory`
- ❌ `_db.Orders.Where(...).ToListAsync()` without `AsNoTracking()` on a read query
- ❌ `DbContext` field on a domain entity
- ❌ `async void` (except event handlers that explicitly document they swallow exceptions)

---

## Current sprint context

_Update each sprint:_

- **Sprint goal:** [e.g. "persistence layer migration to Clean Architecture"]
- **Active feature:** [e.g. "OrderProcessing bounded context"]
- **Known tech debt:** [e.g. "CustomerRepository still uses raw SQL in 2 methods — planned for next sprint"]
