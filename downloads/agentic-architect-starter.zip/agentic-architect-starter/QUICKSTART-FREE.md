# Agentic Architect Starter Kit — 3-Minute Setup

You've got three Cursor rules that stop the three most common regressions on C#/.NET codebases. Here's how to install them and wire in the Learning Log.

## Prerequisites
- Cursor Pro (or free tier — rules work on both)
- A C#/.NET solution open in Cursor

---

## Step 1: Copy the rule files into your repo

```bash
# Run from your solution root
mkdir -p .cursor/rules

# Copy the three rule files into your rules directory
# (they came with this zip — copy from the rules/ folder)
cp path/to/starter/rules/*.mdc .cursor/rules/
```

Or drag-and-drop the three `.mdc` files from `rules/` into `.cursor/rules/` in your file explorer.

Your `.cursor/rules/` directory should now contain:
```
.cursor/rules/
├── result-pattern.mdc
├── di-scoping.mdc
└── ef-core-reads.mdc
```

---

## Step 2: Add the Learning Log

```bash
# Copy LEARNING_LOG.md to your solution root
cp path/to/starter/LEARNING_LOG.md ./LEARNING_LOG.md
```

Then open it and fill in the ADRs that apply to YOUR codebase (delete the ones that don't). 5 minutes now saves 30 minutes of Cursor context drift per week.

---

## Step 3: Create a rule that tells Cursor to read the Learning Log

Create `.cursor/rules/learning-log.mdc`:

```
---
description: Re-read LEARNING_LOG.md at the start of every session
alwaysApply: true
---

# Session startup

At the start of every session, read LEARNING_LOG.md in the repo root.
Apply all ADRs and patterns listed there to every code suggestion you make.
Do not suggest patterns that appear in the anti-patterns list.
```

---

## Step 4: Commit

```bash
git add .cursor/ LEARNING_LOG.md
git commit -m "chore: add Agentic Architect starter rules + Learning Log"
```

---

## Step 5: Test it

Open Cursor and prompt: **"Add a new application service that fetches recent orders for a customer."**

With the rules active, Cursor should:
- Return `Result<IReadOnlyList<OrderSummaryDto>, OrderError>` (not throw)
- Register the service as `AddScoped<>` (not Singleton)
- Use `.AsNoTracking()` on the EF Core query

If it doesn't — open the `.mdc` file it's missing and check the `alwaysApply: true` front matter is present.

---

## What you're now protected against

| Rule | What it prevents |
| --- | --- |
| `result-pattern.mdc` | Cursor throwing exceptions for business failures |
| `di-scoping.mdc` | Scoped-in-Singleton capture bugs (silent in dev, critical in prod) |
| `ef-core-reads.mdc` | Missing `AsNoTracking` on read-only queries (30-50% overhead) |

---

## Want the full 9-rule kit?

The starter covers the three highest-frequency regressions. The full **Agentic Architect Kit** adds six more:

- `clean-architecture.mdc` — enforces layer boundaries (no EF Core in domain)
- `mediatr-pipeline.mdc` — MediatR command/handler/validator standards
- `async-patterns.mdc` — `CancellationToken` propagation on every async call
- `minimal-api.mdc` — Minimal API + Swagger doc standards
- `xunit-conventions.mdc` — test naming + fixture patterns
- `mcp-tools.mdc` — MCP server wiring patterns

Plus: 3 pre-written ADR markdown files, a prompt that auto-hydrates your Learning Log from your existing codebase (saves the 5 minutes of manual ADR writing), and the full 5-minute setup guide covering all 9 rules.

**[Get the full Agentic Architect Kit for £9.00 →](https://buy.stripe.com/9B68wP8XE3I5dZ4aKmcIE01?utm_source=starter&utm_medium=quickstart&utm_campaign=paid_kit)**

v1.0 launch price — will rise to £29.00 when the video walkthrough ships in Q3 2026.
